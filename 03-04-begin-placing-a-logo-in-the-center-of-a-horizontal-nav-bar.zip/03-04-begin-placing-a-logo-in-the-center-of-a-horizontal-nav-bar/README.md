# 03-04 begin: Placing a logo in the center of a horizontal nav bar

A Pen created on CodePen.io. Original URL: [https://codepen.io/jen4web/pen/jOBeGXe](https://codepen.io/jen4web/pen/jOBeGXe).

