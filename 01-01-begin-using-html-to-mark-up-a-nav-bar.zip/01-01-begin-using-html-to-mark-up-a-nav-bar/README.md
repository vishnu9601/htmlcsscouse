# 01-01 begin: Using HTML to mark up a nav bar

A Pen created on CodePen.io. Original URL: [https://codepen.io/vishnu9601/pen/VwEvNJJ](https://codepen.io/vishnu9601/pen/VwEvNJJ).

