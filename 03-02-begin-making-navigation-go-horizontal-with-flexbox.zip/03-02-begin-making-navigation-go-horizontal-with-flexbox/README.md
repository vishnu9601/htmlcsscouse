# 03-02 begin: Making navigation go horizontal with Flexbox

A Pen created on CodePen.io. Original URL: [https://codepen.io/jen4web/pen/mdWzBRE](https://codepen.io/jen4web/pen/mdWzBRE).

