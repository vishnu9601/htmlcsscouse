# 02-02 begin: Enlarging the clickable areas of the link

A Pen created on CodePen.io. Original URL: [https://codepen.io/jen4web/pen/abJGrJp](https://codepen.io/jen4web/pen/abJGrJp).

