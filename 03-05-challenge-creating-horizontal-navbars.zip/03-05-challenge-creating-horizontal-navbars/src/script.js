/* Make this navbar go horizontal. See if you can add the LinkedIn logo to go with this. You'll find that in FontAwesome, along with the other icons.

Jen's final version looks like this:
https://assets.codepen.io/296057/lil-navbars-0305-challenge.png

*/