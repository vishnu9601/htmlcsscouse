# 03-05 Challenge: Creating horizontal navbars

A Pen created on CodePen.io. Original URL: [https://codepen.io/jen4web/pen/OJpBqvB](https://codepen.io/jen4web/pen/OJpBqvB).

