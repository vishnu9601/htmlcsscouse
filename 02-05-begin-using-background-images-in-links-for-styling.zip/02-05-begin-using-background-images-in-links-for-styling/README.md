# 02-05 begin: Using background images in links for styling

A Pen created on CodePen.io. Original URL: [https://codepen.io/jen4web/pen/qBrMdPZ](https://codepen.io/jen4web/pen/qBrMdPZ).

