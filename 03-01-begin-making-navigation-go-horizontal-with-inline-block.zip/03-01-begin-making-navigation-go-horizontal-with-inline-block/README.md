# 03-01 begin: Making navigation go horizontal with inline-block

A Pen created on CodePen.io. Original URL: [https://codepen.io/jen4web/pen/BaWqwyp](https://codepen.io/jen4web/pen/BaWqwyp).

