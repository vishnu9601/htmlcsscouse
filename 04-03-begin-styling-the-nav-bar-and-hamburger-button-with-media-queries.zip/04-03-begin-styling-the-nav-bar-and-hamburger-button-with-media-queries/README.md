# 04-03 begin: Styling the nav bar and hamburger button with media queries

A Pen created on CodePen.io. Original URL: [https://codepen.io/jen4web/pen/KKWGOmM](https://codepen.io/jen4web/pen/KKWGOmM).

