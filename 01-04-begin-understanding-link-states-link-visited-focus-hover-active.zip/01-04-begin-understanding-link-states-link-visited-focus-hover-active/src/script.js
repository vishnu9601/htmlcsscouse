/* Five possible link states, in order:
:link -- before you've visited the site
:visited -- you've viewed the site before
:focus -- when the element is selected
:hover -- when you hover over it
:active -- after the link is clicked, before the next page loads

Remember with the acronym
Lord Vader Former Handle Anakin
or
LiVe Free HAppy 
*/