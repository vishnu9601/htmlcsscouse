# 01-04 begin: Understanding link states: :link, :visited, :focus, :hover, :active

A Pen created on CodePen.io. Original URL: [https://codepen.io/jen4web/pen/dyvmRKP](https://codepen.io/jen4web/pen/dyvmRKP).

