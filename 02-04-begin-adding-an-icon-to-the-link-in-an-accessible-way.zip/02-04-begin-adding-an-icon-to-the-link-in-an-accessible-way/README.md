# 02-04 begin: Adding an icon to the link in an accessible way

A Pen created on CodePen.io. Original URL: [https://codepen.io/jen4web/pen/VwpBbjP](https://codepen.io/jen4web/pen/VwpBbjP).

