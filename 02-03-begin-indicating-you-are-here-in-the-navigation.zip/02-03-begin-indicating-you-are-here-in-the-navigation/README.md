# 02-03 begin: Indicating “you are here” in the navigation

A Pen created on CodePen.io. Original URL: [https://codepen.io/jen4web/pen/poeVmWv](https://codepen.io/jen4web/pen/poeVmWv).

