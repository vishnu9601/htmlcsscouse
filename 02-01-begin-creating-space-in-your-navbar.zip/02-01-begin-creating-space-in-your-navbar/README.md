# 02-01 begin: Creating space in your navbar

A Pen created on CodePen.io. Original URL: [https://codepen.io/jen4web/pen/RwpyjQw](https://codepen.io/jen4web/pen/RwpyjQw).

