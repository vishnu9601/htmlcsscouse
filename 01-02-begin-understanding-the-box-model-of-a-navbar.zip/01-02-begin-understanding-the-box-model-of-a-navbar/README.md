# 01-02 begin: Understanding the box model of a navbar

A Pen created on CodePen.io. Original URL: [https://codepen.io/jen4web/pen/ExWEXgd](https://codepen.io/jen4web/pen/ExWEXgd).

