# 03-03 end: Centering and styling the horizontal navbar

A Pen created on CodePen.io. Original URL: [https://codepen.io/jen4web/pen/qBrJPLb](https://codepen.io/jen4web/pen/qBrJPLb).

