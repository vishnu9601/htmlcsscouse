# 02-06 Challenge: Creating vertical navbars

A Pen created on CodePen.io. Original URL: [https://codepen.io/jen4web/pen/oNZaeoJ](https://codepen.io/jen4web/pen/oNZaeoJ).

