# 01-03 begin: Removing default list styling

A Pen created on CodePen.io. Original URL: [https://codepen.io/jen4web/pen/NWpYgMa](https://codepen.io/jen4web/pen/NWpYgMa).

