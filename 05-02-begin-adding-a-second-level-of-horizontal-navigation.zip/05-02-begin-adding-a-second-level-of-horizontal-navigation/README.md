# 05-02 begin: Adding a second level of horizontal navigation

A Pen created on CodePen.io. Original URL: [https://codepen.io/jen4web/pen/poexMBr](https://codepen.io/jen4web/pen/poexMBr).

